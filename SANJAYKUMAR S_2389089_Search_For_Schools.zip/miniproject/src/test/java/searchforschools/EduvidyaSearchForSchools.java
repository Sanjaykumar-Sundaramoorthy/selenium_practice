package searchforschools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class EduvidyaSearchForSchools {

    // WebDriver instance to control the browser
    private static WebDriver driver;
    // Excel sheet for input data
    private static XSSFSheet sheet;
    // Excel workbook instance
    XSSFWorkbook workbook;
    // File paths for input and output excel files
    private static final String excelFilePath = "C:\\Users\\2389089\\eclipse-workspace\\RestAssuredAPI\\miniproject\\src\\test\\resources\\input.xlsx";
    private static final String resultFilePath = "TestResult.xlsx";
    // Board and city from excel input
    private static String board;
    private static String city;
    // Browser type (chrome or edge)
    private static String Browser;
    // List to store school titles
    private static List<WebElement> title;

    // WebElement for the "Schools in India" link
    @FindBy(css = "a[href='/Schools-in-India.aspx']")
    static WebElement SchoolsLink;

    // ExtentReports and ExtentTest instances for reporting
    private static ExtentReports extent;
    private static ExtentTest test;

    // Setup method executed before the class
    @BeforeClass
    @Parameters("browser")
    public void setup(String browser) throws IOException {
        // Set the browser type
        Browser = browser;
        // Initialize the WebDriver based on browser type
        if (browser.equals("edge")) {
            driver = new EdgeDriver();
        } else if (browser.equals("chrome")) {
            driver = new ChromeDriver();
        }

        // Initialize ExtentReports and attach a Spark reporter
        extent = new ExtentReports();
        ExtentSparkReporter spark = new ExtentSparkReporter("ExtentReports/" + browser + "_report.html");
        extent.attachReporter(spark);

        try {
            // Navigate to the website and handle potential security prompts
            String baseUrl = "https://www.eduvidya.com/";
            driver.get(baseUrl);
            driver.findElement(By.id("details-button")).click();
            driver.findElement(By.id("proceed-link")).click();
            driver.manage().window().maximize();
            PageFactory.initElements(driver, this);
            Thread.sleep(3000);
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }

        // Read board and city from the input excel file
        FileInputStream fis = new FileInputStream(excelFilePath);
        workbook = new XSSFWorkbook(fis);
        sheet = workbook.getSheetAt(0);
        Row row = sheet.getRow(0);
        board = row.getCell(0).toString();
        city = row.getCell(1).toString();
    }

    // Test method to perform the search and capture results
    @Test
    public void test1() throws IOException {
        // Create an ExtentTest instance
        test = extent.createTest("Eduvidya Search For Schools Test");
        // Close any ads that appear
        closeAds();
        // Click the schools link and perform the search
        clickSchoolsLink();   
        test.log(Status.PASS, "School navigation button clicked");
    }
    
    @Test
    public void test2() throws IOException {
    	selectCourseType();
    	test.log(Status.PASS, "Course type 'CBSE' is selected in the dropdown");
    }
    
    @Test
    public void test3() throws IOException {
    	selectCity();
    	test.log(Status.PASS, "City 'Pune' is selected in the dropdown");
    }
    
    @Test
    public void test4() throws IOException {
    	clickSearchButton();
    	test.log(Status.PASS, "Search button is clicked");
    }
    
    @Test
    public void test5() throws IOException {
    	waitForSearchResults();
        // Take a screenshot of the results
        takeScreenshot();
        test.log(Status.PASS, "Test Results are verified and Screenshots of the results is taken");
    }

    // Teardown method to close the browser and excel file
    @AfterClass
    public void teardown() throws IOException {
        // Print the titles of the schools found
        int i = 1;
        if(title != null) {
            for (WebElement ttl : title) {
                System.out.println(i + " " + ttl.getText());
                i += 1;
            }
        }

        // Close the WebDriver
        if (driver != null) {
            driver.quit();
            System.out.print("\n\n");
            System.out.println("Exited from the browser");
            System.out.print("\n\n");
        }

        // Close the excel workbook
        if (sheet != null && sheet.getWorkbook() != null) {
            sheet.getWorkbook().close();
            workbook.close();
        }
        // Flush the ExtentReports instance
        extent.flush();
    }

    // Method to click the "Schools in India" link and perform the search
    private void clickSchoolsLink() {
        WebElement schoolsLink = SchoolsLink;
        if (schoolsLink.isDisplayed() && schoolsLink.isEnabled()) {
            schoolsLink.click();
            System.out.print("\n\n");
            System.out.println("1) Clicking 'Schools' link in the Menu bar");
            System.out.print("\n\n");
            closeAds();
        }
    }
    private void selectCourseType() {
        try {
            System.out.print("\n\n");
            System.out.println("2) Clicking on 'Course-Type' dropdown");
            System.out.println("   Taking category input from 'input.xlsx'");
            System.out.println("3) Selecting “CBSE” from the list");
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement dropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ddl_Category")));
            Select select = new Select(dropdown);
            wait.until(ExpectedConditions.textToBePresentInElementLocated(By.id("ddl_Category"), board));
            select.selectByVisibleText(board);
        } catch (Exception e) {
            System.out.println("Dropdown not found: " + e.getMessage());
        }
    }
    
    private void selectCity() {
        try {
            System.out.print("\n\n");
            System.out.println("4) Clicking on 'City' dropdown");
            System.out.println("   Taking city input from 'input.xlsx'");
            System.out.println("5) Selecting “Pune” from the list");
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement cityDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ddl_City")));
            Select selectCity = new Select(cityDropdown);
            wait.until(ExpectedConditions.textToBePresentInElementLocated(By.id("ddl_City"), city));
            selectCity.selectByVisibleText(city);
        } catch (Exception e) {
            System.out.println("Dropdown not found: " + e.getMessage());
        }
    }
    
    private void clickSearchButton() {
        try {
            System.out.print("\n\n");
            System.out.println("6) Clicking the 'Search' button");
            System.out.print("\n\n");;
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(12));
            WebElement search = wait.until(ExpectedConditions.elementToBeClickable(By.id("btnSearch")));
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", search);
            closeAds();
        } catch (Exception e) {
            System.out.println("Search button not found: " + e.getMessage());
        }
    }

    // Method to wait for the search results to be displayed
    private void waitForSearchResults() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        // Wait for the results list to be visible
        WebElement resultsList = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("ul > li")));
        // Find all the school titles
        title = driver.findElements(By.xpath("//*[@class=\"contentblock\"]//a"));
        // Assert that the list is not empty
        Assert.assertTrue(!title.isEmpty(), "No search results found.");
        try {
            // Write the school titles to the excel file
            writeResultsToExcel(title);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        // Check if the results list is displayed
        if (resultsList.isDisplayed()) {
            System.out.print("\n\n");
            System.out.println("Search results are displayed.");
            try {
                // Wait for a short period
                Thread.sleep(2000);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println("Search results are not displayed.");
        }
    }

    // Method to take a screenshot of the current page
    private void takeScreenshot() throws IOException {
        String screenshotFilePath = "SearchResultScreenshot_" + Browser + ".png";
        File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshotFile, new File(screenshotFilePath));
        System.out.print("\n\n");
        System.out.println("Screenshot taken and saved to: " + screenshotFilePath);
        System.out.print("\n\n");
    }

    // Method to write the school titles to an excel file
    private void writeResultsToExcel(List<WebElement> schoolTitles) throws IOException {
        XSSFWorkbook resultWorkbook = new XSSFWorkbook();
        XSSFSheet resultSheet = resultWorkbook.createSheet("SearchResults");
        // Create the header row
        Row headerRow = resultSheet.createRow(0);
        headerRow.createCell(0).setCellValue("S.No");
        headerRow.createCell(1).setCellValue("School Title");
        // Write each school title to a new row
        for (int i = 0; i < 16; i++) {
            Row dataRow = resultSheet.createRow(i + 1);
            dataRow.createCell(0).setCellValue(i + 1);
            dataRow.createCell(1).setCellValue(schoolTitles.get(i).getText());
        }
        // Save the excel file
        FileOutputStream fos = new FileOutputStream(resultFilePath);
        resultWorkbook.write(fos);
        fos.close();
        resultWorkbook.close();
    }

    // Method to close any ads that appear on the page
    private void closeAds() {
        WebElement adCloseButton = null;
        // Array of locators to find the ad close button
        By[] adLocators = {
                By.id("dismiss-button"),
                By.cssSelector("div[style='cursor: pointer;']"),
                By.cssSelector("div#dismiss-button[aria-label='Close ad']"),
                By.cssSelector("div#dismiss-button[role='button']")
        };

        // Loop through the locators and try to find and click the close button
        for (By locator : adLocators) {
            try {
                adCloseButton = driver.findElement(locator);
                if (adCloseButton.isDisplayed()) {
                    adCloseButton.click();
                    System.out.println("Ad closed using locator: " + locator);
                    return;
                }
            } catch (Exception e) {
                System.out.println("Ad close button not found using locator: " + locator);
            }
        }

        // Handle specific ad iframe if present
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("iframe#aswift_9")));
            System.out.println("Ad iframe is no longer visible.");
        } catch (Exception e) {
            System.out.println("Ad iframe is still visible: " + e.getMessage());
        }

        // Handle google vignette if present
        if (driver.getCurrentUrl().equals("https://www.eduvidya.com/#google_vignette")) {
            driver.navigate().back();
            System.out.println("Navigated back from vignette URL.");
            clickSchoolsLink();
        }

        System.out.println("No ads displayed.");
    }
}
