package pom;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.ExcelUtils;

public class LoginPage extends BasePage{

	WebDriverWait wait;
	List<String> errorList;
	
	public LoginPage(WebDriver driver) {
		super(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        errorList  = new ArrayList<>();
	}
	
	@FindBy(id = "identifierId")
	WebElement email;
	
	@FindBy(css = ".VfPpkd-LgbsSe.VfPpkd-LgbsSe-OWXEXe-k8QpJ")
	WebElement submit;
	
	@FindBy(css = "div[class='Ekjuhf Jj6Lae']")
	WebElement invalidMailError;

	@FindBy(xpath = "//*[@id='headingText']/span")
	WebElement mailError;
	
	public void enterEmail(String mailid) {
		wait.until(ExpectedConditions.visibilityOf(email));
		email.clear();
		email.sendKeys(mailid);
	}
	
	public void clickSubmit() {
		wait.until(ExpectedConditions.elementToBeClickable(submit)).click();
	}
	
	public void errorMessage() throws IOException {
		wait.until(ExpectedConditions.visibilityOf(invalidMailError));
		String errorMsg=invalidMailError.getText();
		System.out.println(errorMsg);
		assertEquals(errorMsg.isEmpty(),false,"there is no error message displayed.");
		errorList.add(errorMsg);
		
	}
	
	public void mailErrorMessage() throws IOException {
		String errorMsg;
		if(mailError.isDisplayed()) {
		wait.until(ExpectedConditions.visibilityOf(mailError));
		errorMsg=mailError.getText();
		assertEquals(errorMsg.isEmpty(),false,"there is no error message displayed.");
		System.out.println("Couldn't sign you in");
		}
		errorMsg="Couldn't sign you in";
		
		errorList.add(errorMsg);
		ExcelUtils excel = new ExcelUtils(driver);
		excel.ExcelErrorMsg(errorList);
	}
	

	
}
