package pom;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NewBikesPage extends BasePage{
    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;
	
    @FindBy(xpath = "//*[@id=\"main-tabs\"]/li[3]")
    WebElement upcomingTab;

    @FindBy(xpath = "//*[@class='lnk-c' and @title='All Upcoming Bikes']")
    WebElement allUpcomingBikes;
    
    @FindBy(xpath="/html/body/div[8]/div/div/div/div[1]/div[1]/h1")
    WebElement newBikesContainer;
    
    public NewBikesPage(WebDriver driver) {
    	super(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        js = (JavascriptExecutor) driver;
    }
    
    public void navigateToUpcomingBikes() {
        wait.until(ExpectedConditions.elementToBeClickable(upcomingTab)).click();
    }

    public void openAllUpcomingBikes() {
        wait.until(ExpectedConditions.elementToBeClickable(allUpcomingBikes));
        js.executeScript("arguments[0].click();", allUpcomingBikes);
    }
    
    public WebElement getNewBikesContainer() {
    	return newBikesContainer;
    }
}
