package pom;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UpcomingBikesPage extends BasePage{
    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;
    
    @FindBy(xpath = "//*[@id=\"modelList\"]/li[8]/div/div/div/div/div/ul/li[5]/a")
    WebElement hondaBikes;
    
    public UpcomingBikesPage(WebDriver driver) {
    	super(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        js = (JavascriptExecutor) driver;
    }
    
    public void selectHondaBikes() {
    	wait.until(ExpectedConditions.elementToBeClickable(hondaBikes));
        js.executeScript("arguments[0].click();", hondaBikes);
    }
    
}
