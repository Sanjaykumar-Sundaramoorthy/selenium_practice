package pom;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.ExcelUtils;

public class UpcomingHondaBikesPage extends BasePage{
   
    WebDriverWait wait;
    JavascriptExecutor js;
    @FindBy(xpath = "//*[@id='modelList']/li")
    List<WebElement> listOfBikes;
    
    public UpcomingHondaBikesPage(WebDriver driver) {
    	super(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        js = (JavascriptExecutor) driver;
    }

    public void verifyBikeDisplay() {
    	wait.until(ExpectedConditions.visibilityOfAllElements(listOfBikes));
    	System.out.println("There are " + listOfBikes.size() + " bikes present in the category.");
    	assertEquals(listOfBikes.size()>=0,true,"No Bike Displayed");
    }
    

    
    public List<List<String>> printBikeDetails() throws InterruptedException {
    	
        List<List<String>> bikeDetailsList = new ArrayList<>();
        for (WebElement bike : listOfBikes) {
            String priceText = bike.findElement(By.xpath("./div/div[3]/div[1]")).getText();
            String[] priceParts = priceText.split(" ");

            if (priceParts.length == 2 || (priceParts.length == 3 && Double.parseDouble(priceParts[1]) < 4.0)) {
                try {
                   
                        String name = bike.findElement(By.xpath("./div/div[3]/a/strong")).getText();
                        String releaseDate = bike.findElement(By.xpath("./div/div[3]/div[2]")).getText();

                        List<String> bikeInfo = new ArrayList<>();
                        bikeInfo.add(name);
                        bikeInfo.add(priceText);
                        bikeInfo.add(releaseDate);
                        bikeDetailsList.add(bikeInfo);

                        System.out.println("Bike Name: " + name);
                        System.out.println("Price: " + priceText);
                        System.out.println("Expected Launch: " + releaseDate);
                    
                } catch (NumberFormatException e) {
                    System.err.println("Could not parse price for a bike: " + priceText);
                }
            }
        }
        assertEquals(bikeDetailsList.size() > 0, true, "No Bikes Less than 4 Lakhs is Displayed");
        return bikeDetailsList;
    }
        public void PrintBikeDetailsBelow4Lakh() throws IOException, InterruptedException {
            ExcelUtils excelUtils = new ExcelUtils(driver);
            List<List<String>> bikeDetails = printBikeDetails();
            excelUtils.ExcelSetUpBike(bikeDetails);
        }
    }

 

