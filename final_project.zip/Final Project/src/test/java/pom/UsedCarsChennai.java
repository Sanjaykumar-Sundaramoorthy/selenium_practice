package pom;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class UsedCarsChennai extends BasePage{
	WebDriver driver;
	
	@FindBy(css="a[title='Chennai']")
	WebElement location;
	
	@FindBy(xpath="//li[contains(@id,'mmvLi')]/label")
	List<WebElement> popularCarModels;
	
	@FindBy(id="usedCarCity")
	WebElement locationInput;
	
	public UsedCarsChennai(WebDriver driver) {
		super(driver);
	}
	
	public void locationSelector() {
		location.click();
	}
	
	public void locationChecker() {
		String locate = locationInput.getDomProperty("value");
		System.out.println(locate);
		assertEquals(locate.equalsIgnoreCase("Chennai"),true,"Location is not correct");
		}
	
	public void popularCars() {
		for(WebElement str:popularCarModels) {
			System.out.println(str.getText());
		}
	}
}
