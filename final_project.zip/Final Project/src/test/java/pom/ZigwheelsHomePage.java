package pom;

import java.time.Duration;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class ZigwheelsHomePage extends BasePage{
	WebDriver driver;
	WebDriverWait wait;
	
	public ZigwheelsHomePage(WebDriver driver) {
		super(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}
	
	@FindBy(id="forum_login_title_lg")
	WebElement btnLoginandMore;
	
	@FindBy(xpath="//*[@id=\"headerNewVNavWrap\"]/nav/ul/li[3]/a")
	WebElement btnNewBikes;
	
	@FindBy(xpath="//*[@id=\"headerNewVNavWrap\"]/nav/ul/li[5]/span")
	WebElement drpMore;
	
	@FindBy(xpath="//a[@title='Used Cars']")
	WebElement btnUsedCars;
	
	@FindBy(css="div[class='lgn-sc c-p txt-l pl-30 pr-30 googleSignIn']")
	WebElement google;
	
	@FindBy(xpath="//*[@id=\"headerSearch\"]")
	WebElement searchBox;
	
	@FindBy(xpath="/html/body/div[8]/div/div/div/div[1]")
	WebElement cntNewBikes;
	
	@FindBy(xpath="/html/body/footer/div[3]/span")
	WebElement cntCopyrights;
	
	public void clickNewBikes() {
		wait.until(ExpectedConditions.elementToBeClickable(btnNewBikes)).click();
	}
	
	public void clickUsedCarsBtn() {
		btnUsedCars.click();
	}
	
	public void clickMoreDropdown() {
		drpMore.click();
	}
	public void clickLoginAndMoreBtn() {
		wait.until(ExpectedConditions.visibilityOf(btnLoginandMore)).click();
	}
	
	public WebElement getNewBikesContainer() {
		return cntNewBikes;
	}
	
	public WebElement getCopyrightsContainer() {
		return cntCopyrights;
	}
 
	public WebElement getLoginandMoreBtn() {
		return btnLoginandMore;
	}
	
	public void searchBoxInput(String searchInput) {
		searchBox.sendKeys(searchInput);
		searchBox.sendKeys(Keys.ENTER);
	}
	
	public void clickGoogle() {
		wait.until(ExpectedConditions.elementToBeClickable(google)).click();
	}
	

}


