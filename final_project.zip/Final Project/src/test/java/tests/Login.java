package tests;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import pom.LoginPage;
import pom.ZigwheelsHomePage;
import utils.DriverSetup;

public class Login {

    ZigwheelsHomePage zigwheels;
    LoginPage login;
    WebDriver driver;

    @Parameters("browser")
    @BeforeSuite
    public void setUpSuite(String browser) {
        driver = DriverSetup.initializeDriver(browser);
    }

    @BeforeClass
    public void setUpClass() {
        zigwheels = new ZigwheelsHomePage(driver);
        login = new LoginPage(driver);
    }

    @Test(priority = 0)
    public void TC_Zigwheels_018_EmptyEmail() throws IOException {
        zigwheels.clickLoginAndMoreBtn();
        zigwheels.clickGoogle();
        DriverSetup.changeHandler();
        login.clickSubmit();
        login.errorMessage();
    }

    @Test(priority = 1)
    public void TC_Zigwheels_019_InvalidEmail() throws IOException {
        login.enterEmail("admin");
        login.clickSubmit();
        login.errorMessage();
    }

    @Test(priority = 2)
    public void TC_Zigwheels_020_InvalidEmailFormat() throws IOException {
        login.enterEmail("sanjay@monkeyD");
        login.clickSubmit();
        login.errorMessage();
    }

    @Test(priority = 3)
    public void TC_Zigwheels_021_validEmail() throws IOException {
        login.enterEmail("sanjaysundaram2004");
        login.clickSubmit();
        login.mailErrorMessage();
    }

    @AfterClass
    public void refreshPage() {
        driver.get("http://zigwheels.com");
    }

    @AfterSuite
    public void tearDownSuite() {
        DriverSetup.quitDriver();
    }
}
