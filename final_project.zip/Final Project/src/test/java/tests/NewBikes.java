package tests;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import pom.NewBikesPage;
import pom.UpcomingBikesPage;
import pom.UpcomingHondaBikesPage;
import pom.ZigwheelsHomePage;
import utils.DriverSetup;

public class NewBikes {

    ZigwheelsHomePage zigwheels;
    NewBikesPage newBikePom;
    UpcomingBikesPage upcomingBikePom;
    UpcomingHondaBikesPage hondaPom;
    WebDriver driver;

    @Parameters("browser")
    @BeforeSuite
    public void setUpSuite(String browser) {
        driver = DriverSetup.initializeDriver(browser);
    }

    @BeforeClass
    public void setUpClass() {
        zigwheels = new ZigwheelsHomePage(driver);
        newBikePom = new NewBikesPage(driver);
        upcomingBikePom = new UpcomingBikesPage(driver);
        hondaPom = new UpcomingHondaBikesPage(driver);
    }

    @Test(priority = -1)
    public void TC_Zigwheels_006_VerifySearchBoxNavigation() {
        zigwheels.searchBoxInput("Upcoming Honda Bikes");
        hondaPom.verifyBikeDisplay();
    }

    @Test(priority = 0)
    public void TC_Zigwheels_007_VerifyNewBikesNavigation() {
        zigwheels.clickNewBikes();
    }

    @Test(priority = 1)
    public void TC_Zigwheels_008_VerifyUpcomingSectionNavigation() {
        newBikePom.navigateToUpcomingBikes();
    }

    @Test(priority = 2)
    public void TC_Zigwheels_009_VerifyAllUpcomingBikesNavigation() {
        newBikePom.openAllUpcomingBikes();
    }

    @Test(priority = 3)
    public void TC_Zigwheels_010_VerifyHondaSectionNavigation() {
        upcomingBikePom.selectHondaBikes();
    }

    @Test(priority = 4)
    public void TC_Zigwheels_011_VerifyUpcomingHondaBikesDisplay() {
        hondaPom.verifyBikeDisplay();
    }

    @Test(priority = 5)
    public void TC_Zigwheels_012_VerifyBikesUnder4LakhsDisplay() throws IOException, InterruptedException {
        hondaPom.PrintBikeDetailsBelow4Lakh();
    }

    @AfterClass
    public void refreshPage() {
        driver.get("http://zigwheels.com");
    }

    @AfterSuite
    public void tearDownSuite() {
        DriverSetup.quitDriver();
    }
}
