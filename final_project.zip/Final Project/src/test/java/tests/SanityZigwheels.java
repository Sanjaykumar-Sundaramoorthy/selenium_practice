package tests;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import pom.ZigwheelsHomePage;
import utils.DriverSetup;

public class SanityZigwheels {

    WebDriver driver;
    DriverSetup setup;
    String expectedUrl = "https://www.zigwheels.com/";
    String expectedTitle = "New Cars & Bikes, Prices, News, Reviews, Buy & Sell Used Cars - ZigWheels.com";
    ZigwheelsHomePage homepage;

    @Parameters("browser")
    @BeforeSuite
    public void setUpSuite(String browser) {
        driver = DriverSetup.initializeDriver(browser);
    }

    @BeforeClass
    public void setUpClass() {
        homepage = new ZigwheelsHomePage(driver);
    }

    @Test(priority = 0)
    public void TC_Zigwheels_001_VerifyURL() {
        String actualUrl = driver.getCurrentUrl();
        Assert.assertEquals(expectedUrl, actualUrl);
    }

    @Test(priority = 1)
    public void TC_Zigwheels_002_CheckVisibility() {
        String actualTitle = driver.getTitle();
        Assert.assertEquals(expectedTitle, actualTitle);
    }

    @Test(priority = 2)
    public void TC_Zigwheels_003_ValidateLogin() {
        Assert.assertTrue(homepage.getLoginandMoreBtn().isEnabled());
    }

    @Test(priority = 3)
    public void TC_Zigwheels_004_ScrollToBottom() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
        Assert.assertTrue(homepage.getCopyrightsContainer().isDisplayed());
    }

    @Test(priority = 4)
    public void TC_Zigwheels_005_ClickMainFeature() {
        homepage.clickNewBikes();
        Assert.assertTrue(homepage.getNewBikesContainer().isDisplayed());
        driver.navigate().back();
    }

    @AfterClass
    public void refreshPage() {
        driver.get("http://zigwheels.com");
    }

    @AfterSuite
    public void tearDownSuite() {
        DriverSetup.quitDriver();
    }
}
