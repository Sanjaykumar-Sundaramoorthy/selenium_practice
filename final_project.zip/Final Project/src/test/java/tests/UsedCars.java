package tests;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import pom.UsedCarsChennai;
import pom.ZigwheelsHomePage;
import utils.DriverSetup;
import utils.ExcelUtils;

public class UsedCars {
    ZigwheelsHomePage zigwheels;
    UsedCarsChennai usedCars;
    ExcelUtils excel;
    WebDriver driver;

    @Parameters("browser")
    @BeforeSuite
    public void setUpSuite(String browser) {
        driver = DriverSetup.initializeDriver(browser);
    }

    @BeforeClass
    public void setUpClass() {
        zigwheels = new ZigwheelsHomePage(driver);
        usedCars = new UsedCarsChennai(driver);
        excel = new ExcelUtils(driver);
    }

    @Test(priority = 0)
    public void TC_Zigwheels_013_VerifyMoreSectionExpansion() {
        zigwheels.clickMoreDropdown();
    }

    @Test(priority = 1)
    public void TC_Zigwheels_014_VerifyUsedCarsSubmenuNavigation() {
        zigwheels.clickUsedCarsBtn();
    }

    @Test(priority = 2)
    public void TC_Zigwheels_015_VerifyUsedCarsPageLocationPrompt() {
        usedCars.locationSelector();
    }

    @Test(priority = 3)
    public void TC_Zigwheels_016_VerifyLocationOptionDisplaysChennai() {
        usedCars.locationChecker();
    }

    @Test(priority = 4)
    public void TC_Zigwheels_017_VerifyFiltersMenuDisplaysPopularModels() throws IOException {
        usedCars.popularCars();
        excel.ExcelSetUpCar();
    }

    @AfterClass
    public void refreshPage() {
        driver.get("http://zigwheels.com");
    }

    @AfterSuite
    public void tearDownSuite() {
        DriverSetup.quitDriver();
    }
}
