package utils;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

public class DriverSetup {
    
    private static WebDriver driver;

    @Parameters({"browser"})
    @BeforeClass
    public void setup(String browser) {
        initializeDriver(browser);
    }

    public static WebDriver initializeDriver(String browser) {
        if (driver == null) {
            if (browser.equalsIgnoreCase("chrome")) {
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--disable-notifications");
                driver = new ChromeDriver(options);
            } else if (browser.equalsIgnoreCase("edge")) {
                EdgeOptions options = new EdgeOptions();
                options.addArguments("--disable-notifications");
                driver = new EdgeDriver(options);
            }
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
            driver.manage().window().maximize();
            driver.get("https://www.zigwheels.com");
        }
        return driver;
    }

    public static void quitDriver() {
        if (driver != null) {
            driver.quit();
            driver = null;
        }
    }

    public static WebDriver getDriver() {
        return driver;
    }

    public static void changeHandler() {
        String homeHandle = driver.getWindowHandle();
        String loginHandle = "";
        Set<String> windowHandles = driver.getWindowHandles();
        for (String it : windowHandles) {
            if (!homeHandle.equals(it)) {
                loginHandle = it;
            }
        }
        driver.switchTo().window(loginHandle);
    }
}
