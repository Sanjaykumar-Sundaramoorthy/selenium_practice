package utils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pom.BasePage;

public class ExcelUtils extends BasePage{
	@FindBy(xpath = "//label[contains(@for,'bycarid')]")
    List<WebElement> carBrandList;
	
	@FindBy(xpath = "//*[@id='modelList']/li")
    List<WebElement> listOfBikes;
	
	public ExcelUtils(WebDriver driver) {
		super(driver);
	}
	
	public void ExcelSetUpBike(List<List<String>> bikeDetails) throws IOException{
		Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Upcoming Honda Bikes");

        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);

        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setFont(headerFont);

        Row headerRow = sheet.createRow(0);

        Cell nameHeaderCell = headerRow.createCell(0);
        nameHeaderCell.setCellValue("Bike Name");
        nameHeaderCell.setCellStyle(headerStyle);

        Cell priceHeaderCell = headerRow.createCell(1);
        priceHeaderCell.setCellValue("Price");
        priceHeaderCell.setCellStyle(headerStyle);

        Cell launchHeaderCell = headerRow.createCell(2);
        launchHeaderCell.setCellValue("Expected Launch");
        launchHeaderCell.setCellStyle(headerStyle);

        int rowIndex = 1;
        for (List<String> bikeInfo : bikeDetails) {
            Row dataRow = sheet.createRow(rowIndex++);
            for (int i = 0; i < bikeInfo.size(); i++) {
                Cell cell = dataRow.createCell(i);
                cell.setCellValue(bikeInfo.get(i));
            }
        }

        sheet.autoSizeColumn(0);
        sheet.autoSizeColumn(1);
        sheet.autoSizeColumn(2);

        try (FileOutputStream fileOut = new FileOutputStream("UpcomingHondaBikes.xlsx")) {
            workbook.write(fileOut);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            workbook.close();
        }
    }
	public void ExcelSetUpCar() throws IOException{
		// TODO Auto-generated method stub
		Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Popular Models");
 
        Font headerFont = workbook.createFont();
        headerFont.setBold(true); // Set bold
        headerFont.setFontHeightInPoints((short) 12);
 
        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setFont(headerFont); // Apply font to style
 
        // Add header row
        Row headerRow = sheet.createRow(0);
        Cell headerCell = headerRow.createCell(0);
        headerCell.setCellValue("Popular Models");
        headerCell.setCellStyle(headerStyle); // Apply bold style to the header cell
 
        int rowIndex = 1;
        for (WebElement pm : carBrandList) {
        	String modelName = pm.getText();
            Row row = sheet.createRow(rowIndex++);
            Cell cell = row.createCell(0);
            cell.setCellValue(modelName);
        }
 
        // Adjust column width
        sheet.autoSizeColumn(0);
 
        // Write the workbook to a file
        try (FileOutputStream fileOut = new FileOutputStream("PopularModels.xlsx")) {
            workbook.write(fileOut);
        } catch (IOException e) {
            e.printStackTrace();
        }
 
        // Close the workbook
        workbook.close();
	}
	
	public void ExcelErrorMsg(List<String> errorMessages) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Error Messages");

        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);

        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setFont(headerFont);

        Row headerRow = sheet.createRow(0);
        Cell headerCell = headerRow.createCell(0);
        headerCell.setCellValue("Error Messages");
        headerCell.setCellStyle(headerStyle);

        int rowIndex = 1;
        for (String errorMessage : errorMessages) {
            Row dataRow = sheet.createRow(rowIndex++);
            Cell errorCell = dataRow.createCell(0);
            errorCell.setCellValue(errorMessage);
        }

        sheet.autoSizeColumn(0);

        try (FileOutputStream fileOut = new FileOutputStream("ErrorMessages.xlsx")) {
            workbook.write(fileOut);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (workbook != null) {
                workbook.close();
            }
        }
    }

}
