package utils;

//utilities/extentReportManager.java

//import java.text.SimpleDateFormat;
//import java.util.Date;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager implements ITestListener {

 public ExtentSparkReporter sparkReporter;
 public ExtentReports extent;
 public ExtentTest test;

 String repName;

 public void onStart(ITestContext testContext) {
//     String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
     String browser = testContext.getCurrentXmlTest().getParameter("browser");
     repName = "Test-Report-" + browser + ".html";
     sparkReporter = new ExtentSparkReporter(".\\reports\\" + repName);
     sparkReporter.config().setDocumentTitle("ZigWheel Automation Report");
     sparkReporter.config().setReportName("ZigWheel Functional Testing");
     sparkReporter.config().setTheme(Theme.DARK);
     extent = new ExtentReports();
     extent.attachReporter(sparkReporter);
     extent.setSystemInfo("Application", "ZigWheel");
     extent.setSystemInfo("Tester Name", System.getProperty("user.name"));
     extent.setSystemInfo("Environment", "QA");
     
     extent.setSystemInfo("Browser", browser);
 }

// public void onTestStart(ITestResult result) {
//     test = extent.createTest(result.getTestClass().getName() + " - " + result.getName());
// }

 public void onTestSuccess(ITestResult result) {
 	test = extent.createTest(result.getTestClass().getName() + " - " + result.getName());
     test.log(Status.PASS, result.getName() + " got successfully executed");
     test.log(Status.INFO, String.valueOf(result.getTestContext()));
//     try {
//         ITestContext context = result.getTestContext();
//         WebDriver driver = (WebDriver) context.getAttribute("WebDriver");
//         String brName = context.getCurrentXmlTest().getParameter("browser");
//         String path = screenShot.captureScreen(driver, result.getName(),brName);
//         test.addScreenCaptureFromPath(path);
//     } catch (Exception e) {
//         test.log(Status.WARNING, "Screenshot capture failed for success: " + e.getMessage());
//         e.printStackTrace();
//     }
 }

 public void onTestFailure(ITestResult result) {
 	test = extent.createTest(result.getTestClass().getName() + " - " + result.getName());
     test.assignCategory(result.getMethod().getGroups());
     test.log(Status.FAIL, result.getName() + " got failed");
     test.log(Status.INFO, result.getThrowable().getMessage());
     test.log(Status.INFO, result.getThrowable()); // Log the exception stack trace in the report
//     try {
//         ITestContext context = result.getTestContext();
//         WebDriver driver = (WebDriver) context.getAttribute("WebDriver");
//         String brName = context.getCurrentXmlTest().getParameter("browser");
////         String path = screenShot.captureScreen(driver, result.getName(),brName);
////         test.addScreenCaptureFromPath(path);
//     } catch (Exception e) {
//         test.log(Status.WARNING, "Screenshot capture failed for failure: " + e.getMessage());
//         e.printStackTrace();
//     }
 }

 public void onTestSkipped(ITestResult result) {
     test = extent.createTest(result.getTestClass().getName() + " - " + result.getName());
     test.assignCategory(result.getMethod().getGroups());
     test.log(Status.SKIP, result.getName() + " got skipped");
     test.log(Status.INFO, result.getThrowable().getMessage());
 }

 public void onFinish(ITestContext testContext) {
     extent.flush();
 }
}
